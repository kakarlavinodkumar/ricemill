import pyexcel as p

p.save_book_as(file_name='269_RSV_Rice_Industries_3.xls',
               dest_file_name='269_RSV_Rice_Industries_3.xlsx')